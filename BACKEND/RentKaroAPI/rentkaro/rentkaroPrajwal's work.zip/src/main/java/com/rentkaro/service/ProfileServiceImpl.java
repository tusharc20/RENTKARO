package com.rentkaro.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class ProfileServiceImpl implements ProfileService {

	@Override
	public String deleteAccount() {
		// TODO Auto-generated method stub
		return null;
	}

}
