package com.rentkaro.service;

import org.springframework.beans.factory.annotation.Autowired;

public interface ProfileService {
	
	String deleteAccount();
	
}
